# dct-geo-attack

Tac gia: Hoàng Anh Khoa  
Ma sinh vien: b22dcat164  
Hoc phan: Ky thuat giau tin  
Muc do: Kho  
Chu de: Tan cong hinh hoc vao giau tin trong anh bang phuong phap bien doi mien tan so DCT

## Nguyen tac local-first

Du `start.config` co `REGISTRY hackato`, lan chay dau tien cua nguoi tao lab phai build image local:

```bash
cd ~/labtainer/trunk/scripts/labtainer-student
labtainer -r dct-geo-attack
```

Khong dung `labtainer dct-geo-attack` cho lan test dau neu image chua duoc build local hoac chua duoc push len DockerHub.

## Kien thuc nen

DCT la Discrete Cosine Transform, bien doi mot block anh tu mien khong gian sang mien tan so. Trong lab nay anh 512x512 duoc chia thanh cac block 8x8 giong cach JPEG xu ly anh. Moi block co cac he so tan so thap, trung binh va cao.

He so tan so thap mang nhieu nang luong nen sua doi de bi nhin thay. He so tan so cao de mat khi nen hoac noi suy. Vi vay lab nhung bit vao cap he so mid-frequency `(3,4)` va `(4,3)` de can bang giua kho nhan thay va kha nang chiu bien doi.

Tan cong hinh hoc nhu translation, crop, rotation va scaling lam lech vi tri block 8x8. Khi block extraction khong con trung voi block da nhung, quan he giua hai he so DCT bi dao lon va BER tang.

BER la Bit Error Rate, ty le bit trich xuat sai so voi thong diep goc. PSNR la Peak Signal-to-Noise Ratio, do do khac biet giua cover va stego; PSNR cang cao thi thay doi cang kho nhan thay.

## Thong diep bat buoc

Thong diep duoc nhung trong anh la:

```text
HOANG ANH KHOA B22DCAT164
```

## Cach chay cac task

Trong terminal container cua Labtainer, chay tung lenh rieng, thay doi tham so, doc BER in tren terminal va quan sat anh sau moi buoc. Cac report chi dung lam bang chung de `checkwork`.

```bash
python3 generate_cover.py
python3 embed_message.py --alpha 25 --repeat 3
python3 extract_message.py --image stego.png --repeat 3
python3 embed_message.py --alpha 35 --repeat 5
python3 extract_message.py --image stego.png --repeat 5
python3 visualize_dct.py
python3 attack_translation.py --dx 2 --dy 2
python3 attack_translation.py --dx 5 --dy 5
python3 attack_translation.py --dx 10 --dy 10
python3 attack_translation.py --dx 20 --dy 20
python3 attack_crop.py --percent 5
python3 attack_crop.py --percent 10
python3 attack_crop.py --percent 20
python3 attack_crop.py --percent 30
python3 attack_rotation.py --angle 1
python3 attack_rotation.py --angle 3
python3 attack_rotation.py --angle 5
python3 attack_rotation.py --angle 10
python3 attack_scaling.py --scale 90
python3 attack_scaling.py --scale 75
python3 attack_scaling.py --scale 50
python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py
python3 summary.py
```

Khong nen chi chay mot lenh tong hop roi bo qua viec doc ket qua. Muc tieu cua lab la quan sat BER thay doi the nao khi anh bi mat dong bo hinh hoc.

## Task 1 - Baseline DCT Embedding

`generate_cover.py` sinh `cover.png` 512x512 voi gradient, texture, hinh khoi, canh bien va chu PTIT / DCT GEO. `embed_message.py` nhung thong diep bang DCT block 8x8. Sinh vien phai thu it nhat hai cau hinh, vi du `--alpha 25 --repeat 3` va `--alpha 35 --repeat 5`, so sanh PSNR in tren terminal, roi giu cau hinh tot hon de lam cac task sau.

Report hop le phai co:

```text
Baseline DCT embedding successful
```

## Task 2 - Baseline Extraction

`extract_message.py` trich xuat tu `stego.png` sach va in BER. Neu khong co loi bit, report phuc vu checkwork co:

```text
Clean extraction BER = 0.00%
```

## Task 3 - DCT Spectrum Visualization

`visualize_dct.py` tao `dct_spectrum_before.png` de quan sat nang luong DCT trung binh cua cac block. Report `visual_report.txt` co:

```text
DCT spectrum visualized
```

## Task 4 den Task 8 - Tan cong hinh hoc

`attack_translation.py` chay tung muc bang `--dx --dy`: `(2,2)`, `(5,5)`, `(10,10)`, `(20,20)`.  
`attack_crop.py` chay tung muc bang `--percent`: 5, 10, 20, 30.  
`attack_rotation.py` chay tung muc bang `--angle`: 1, 3, 5, 10.  
`attack_scaling.py` chay tung muc bang `--scale`: 90, 75, 50.  
`attack_composite.py` nhan tham so `--angle`, `--dx`, `--dy`, `--crop`; cau hinh mac dinh yeu cau la rotate 3 do, translate 5 px va crop 10%.

Moi script in BER va thong diep trich xuat ra terminal. Marker trong report chi xuat hien sau khi chay du cac muc yeu cau, de `checkwork` khong pass khi sinh vien moi chay mot muc.

## Task 9 - Geometric Resynchronization Defense

Mo `registration_defense.py` va tim phan TODO. Sinh vien can thu chinh:

```python
SEARCH_RADIUS = 8
ROTATION_CANDIDATES = [-5, -3, -1, 0, 1, 3, 5]
SCALE_CANDIDATES = [0.90, 0.95, 1.0, 1.05, 1.10]
REPEAT_N = 5
ALPHA = 35.0
```

Script thu cac cau hinh bu hinh hoc va chon cau hinh co BER nho nhat. Dieu kien qua task: PSNR cua stego >= 35 dB, BER sau defense <= 15%, `REPEAT_N >= 5`, `ALPHA` trong `[25.0, 60.0]`, va `SEARCH_RADIUS >= 8`.

Neu dat, `defense_report.txt` co:

```text
Geometric resynchronization defense PASSED
```

## Task 10 - Summary

`summary.py` tong hop PSNR, BER sach, BER sau cac tan cong, BER sau defense va nhan xet trade-off giua imperceptibility, robustness va capacity. Report hop le co:

```text
Summary Completed
```

## Checkwork

Sau khi chay tung task:

```bash
checkwork
```

Neu can dung lab:

```bash
stoplab dct-geo-attack
```
