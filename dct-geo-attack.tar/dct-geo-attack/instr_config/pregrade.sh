#!/bin/bash
: <<'END'
Default Labtainer pregrade hook. This lab does not need browser or database
processing before grading, but the executable pregrade script is retained so
the grader container follows the standard checkwork structure.
END

homedir=$1
destdir=$2
dbg=/tmp/pregrade.log
cd "$homedir/$destdir" || exit 0

is_sqlite=`which sqlite3`
if [ ! -z $is_sqlite ]; then
   here=`pwd`
   places=$here/.mozilla/firefox/*default/places.sqlite
   for fname in $(ls $places 2> /dev/null); do
     if [[ -f $fname ]]; then
        outpath=$here/.local/result
        outfile=$outpath/moz_places.txt
        mkdir -p "$outpath"
        sqlite3 "$fname" "SELECT moz_places.* FROM moz_places;" >"$outfile"
     fi
   done
fi

exit 0
