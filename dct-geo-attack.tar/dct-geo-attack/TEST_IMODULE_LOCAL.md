# TEST_IMODULE_LOCAL

Test file tar nhu nguoi dung moi, sau khi da dong goi `dct-geo-attack.tar`.

```bash
cd ~/labtainer/trunk/scripts/labtainer-student
imodule /duong/dan/dct-geo-attack.tar
labtainer -r dct-geo-attack
```

Sau khi terminal container mo ra, chay tung task:

```bash
python3 generate_cover.py
python3 embed_message.py --alpha 35 --repeat 5
python3 extract_message.py --image stego.png --repeat 5
python3 visualize_dct.py
python3 attack_translation.py --dx 2 --dy 2
python3 attack_translation.py --dx 5 --dy 5
python3 attack_translation.py --dx 10 --dy 10
python3 attack_translation.py --dx 20 --dy 20
python3 attack_crop.py --percent 5
python3 attack_crop.py --percent 10
python3 attack_crop.py --percent 20
python3 attack_crop.py --percent 30
python3 attack_rotation.py --angle 1
python3 attack_rotation.py --angle 3
python3 attack_rotation.py --angle 5
python3 attack_rotation.py --angle 10
python3 attack_scaling.py --scale 90
python3 attack_scaling.py --scale 75
python3 attack_scaling.py --scale 50
python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py
python3 summary.py
checkwork
stoplab dct-geo-attack
```
