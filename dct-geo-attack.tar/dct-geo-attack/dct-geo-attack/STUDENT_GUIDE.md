# STUDENT_GUIDE - dct-geo-attack

Tac gia: Hoàng Anh Khoa  
Ma sinh vien: b22dcat164

Lab nay nghien cuu giau tin anh bang DCT block 8x8 va ly do cac tan cong hinh hoc lam extraction that bai.

## Chay tung buoc

```bash
python3 generate_cover.py
python3 embed_message.py --alpha 25 --repeat 3
python3 extract_message.py --image stego.png --repeat 3
python3 embed_message.py --alpha 35 --repeat 5
python3 extract_message.py --image stego.png --repeat 5
python3 visualize_dct.py
python3 attack_translation.py --dx 2 --dy 2
python3 attack_translation.py --dx 5 --dy 5
python3 attack_translation.py --dx 10 --dy 10
python3 attack_translation.py --dx 20 --dy 20
python3 attack_crop.py --percent 5
python3 attack_crop.py --percent 10
python3 attack_crop.py --percent 20
python3 attack_crop.py --percent 30
python3 attack_rotation.py --angle 1
python3 attack_rotation.py --angle 3
python3 attack_rotation.py --angle 5
python3 attack_rotation.py --angle 10
python3 attack_scaling.py --scale 90
python3 attack_scaling.py --scale 75
python3 attack_scaling.py --scale 50
python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py
python3 summary.py
checkwork
```

Hay mo `cover.png`, `stego.png`, cac anh trong `attacks/` va so sanh BER in tren terminal. Cac file report chi la bang chung de `checkwork`, khong phai muc tieu chinh cua bai lab.

## Can nam

DCT chuyen mot block anh sang cac he so tan so. Nhung vao mid-frequency giup tranh sua he so thap qua de thay, va tranh he so cao qua de mat khi anh bi bien doi. Translation, crop, rotation va scaling lam cac block 8x8 bi lech, nen extractor doc sai cap he so da nhung.

BER la ty le bit sai. PSNR do muc khac nhau giua cover va stego; PSNR >= 35 dB thuong cho thay thay doi kho nhin bang mat.

## Defense

Trong `registration_defense.py`, thu chinh `SEARCH_RADIUS`, `ROTATION_CANDIDATES`, `SCALE_CANDIDATES`, `REPEAT_N`, `ALPHA`. Sau moi lan sua:

```bash
python3 embed_message.py
python3 attack_composite.py --angle 3 --dx 5 --dy 5 --crop 10
python3 registration_defense.py
python3 summary.py
checkwork
```

Task 9 chi dat khi `defense_report.txt` co dong `Geometric resynchronization defense PASSED`.
