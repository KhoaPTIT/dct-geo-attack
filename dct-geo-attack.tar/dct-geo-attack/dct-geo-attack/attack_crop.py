import argparse

from geo_attack import crop_resize_image, open_rgb, save_attack
from dct_helper import REPEAT_N, append_metric_row, ensure_stego, extract_message, has_required_rows, terminal_text, work_path, write_report


REQUIRED = {5, 10, 20, 30}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one crop attack experiment.")
    parser.add_argument("--percent", type=int, required=True, choices=[5, 10, 20, 30])
    parser.add_argument("--repeat", type=int, default=REPEAT_N)
    args = parser.parse_args()
    stego = ensure_stego()
    img = open_rgb(stego)
    percent = args.percent / 100.0
    out = work_path(f"attacks/crop_{args.percent}.png")
    save_attack(crop_resize_image(img, percent), out)
    result = extract_message(out, repeat_n=args.repeat)
    rows = append_metric_row(
        work_path("crop_metrics.json"),
        ("percent",),
        {"percent": args.percent, "ber": result["ber"], "message": result["message"]},
    )
    complete = has_required_rows(rows, ("percent",), {(x,) for x in REQUIRED})
    lines = ["Crop Attack BER Analysis" if complete else "Crop Attack Experiments In Progress"]
    lines.append("Required percent: 5, 10, 20, 30")
    lines.append("crop_percent,BER_percent,recovered_message")
    for row in rows:
        lines.append(f"{row['percent']},{row['ber'] * 100.0:.2f},{row['message']}")
    write_report(work_path("crop_report.txt"), lines)
    print(f"crop={args.percent}% image=attacks/crop_{args.percent}.png")
    print(f"BER={result['ber'] * 100.0:.2f}% recovered={terminal_text(result['message'])}")
    print("Completed all required crop levels." if complete else "Run the remaining required crop levels.")


if __name__ == "__main__":
    main()
