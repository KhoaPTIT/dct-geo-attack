from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    from scipy.fftpack import dct, idct
except ImportError:
    dct = None
    idct = None


LAB_NAME = "dct-geo-attack"
AUTHOR = "Hoang Anh Khoa"
STUDENT_ID = "b22dcat164"
MESSAGE = "HOANG ANH KHOA B22DCAT164"
SEED = 1642026
IMAGE_SIZE = 512
BLOCK_SIZE = 8
COEFF_A = (3, 4)
COEFF_B = (4, 3)
ALPHA = 35.0
REPEAT_N = 5
_DCT_MATRIX: np.ndarray | None = None


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def work_path(name: str) -> Path:
    return script_dir() / name


def message_bits(message: str = MESSAGE) -> list[int]:
    bits: list[int] = []
    for byte in message.encode("ascii"):
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    return bits


def bits_to_message(bits: list[int]) -> str:
    out = bytearray()
    for i in range(0, len(bits), 8):
        chunk = bits[i : i + 8]
        if len(chunk) < 8:
            break
        value = 0
        for bit in chunk:
            value = (value << 1) | int(bit)
        out.append(value)
    return out.decode("ascii", errors="replace")


def terminal_text(text: str) -> str:
    return text.encode("ascii", errors="replace").decode("ascii")


def bit_error_rate(expected: str, recovered: str) -> float:
    exp = message_bits(expected)
    got = message_bits(recovered.ljust(len(expected))[: len(expected)])
    errors = sum(a != b for a, b in zip(exp, got))
    return errors / len(exp)


def bit_error_rate_from_bits(expected_bits: list[int], recovered_bits: list[int]) -> float:
    if not expected_bits:
        return 0.0
    errors = sum(a != b for a, b in zip(expected_bits, recovered_bits))
    errors += abs(len(expected_bits) - len(recovered_bits))
    return errors / len(expected_bits)


def dct2(block: np.ndarray) -> np.ndarray:
    if dct is not None:
        return dct(dct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat @ block @ mat.T


def idct2(block: np.ndarray) -> np.ndarray:
    if idct is not None:
        return idct(idct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat.T @ block @ mat


def dct_matrix() -> np.ndarray:
    global _DCT_MATRIX
    if _DCT_MATRIX is not None:
        return _DCT_MATRIX
    n = BLOCK_SIZE
    mat = np.zeros((n, n), dtype=np.float64)
    for k in range(n):
        scale = math.sqrt(1.0 / n) if k == 0 else math.sqrt(2.0 / n)
        for i in range(n):
            mat[k, i] = scale * math.cos(math.pi * (2 * i + 1) * k / (2 * n))
    _DCT_MATRIX = mat
    return mat


def block_order(bit_count: int, repeat_n: int = REPEAT_N, seed: int = SEED) -> np.ndarray:
    total_blocks = (IMAGE_SIZE // BLOCK_SIZE) ** 2
    needed = bit_count * repeat_n
    if needed > total_blocks:
        raise ValueError(f"Need {needed} DCT blocks but only {total_blocks} are available")
    rng = np.random.default_rng(seed)
    return rng.permutation(total_blocks)[:needed]


def load_gray(path: str | Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L"), dtype=np.float64)


def save_gray_as_rgb(array: np.ndarray, path: str | Path) -> None:
    clipped = np.clip(np.rint(array), 0, 255).astype(np.uint8)
    Image.fromarray(clipped, mode="L").convert("RGB").save(path)


def ensure_cover() -> Path:
    cover = work_path("cover.png")
    if not cover.exists():
        generate_cover(cover)
    return cover


def generate_cover(path: str | Path) -> None:
    size = IMAGE_SIZE
    y, x = np.mgrid[0:size, 0:size]
    gradient = 70 + 90 * (x / (size - 1)) + 45 * (y / (size - 1))
    texture = 12 * np.sin(x / 9.0) + 10 * np.cos(y / 13.0) + 8 * np.sin((x + y) / 17.0)
    base = np.clip(gradient + texture, 0, 255).astype(np.uint8)

    r = np.clip(base + 20 * np.sin(y / 31.0), 0, 255).astype(np.uint8)
    g = np.clip(base + 15 * np.cos(x / 29.0), 0, 255).astype(np.uint8)
    b = np.clip(255 - base / 2 + 25 * np.sin((x - y) / 23.0), 0, 255).astype(np.uint8)
    rgb = np.dstack([r, g, b]).astype(np.uint8)
    img = Image.fromarray(rgb, mode="RGB")
    draw = ImageDraw.Draw(img)

    draw.rectangle((36, 42, 476, 470), outline=(245, 245, 245), width=4)
    draw.rectangle((66, 82, 220, 210), outline=(220, 45, 45), width=5)
    draw.ellipse((286, 74, 438, 226), outline=(35, 95, 210), width=6)
    draw.line((40, 350, 470, 250), fill=(255, 235, 60), width=5)
    draw.line((60, 392, 452, 392), fill=(35, 35, 35), width=3)
    draw.polygon([(260, 330), (335, 280), (430, 350), (370, 430)], outline=(30, 150, 95), fill=None)

    font_big = ImageFont.load_default()
    font_small = ImageFont.load_default()
    draw.text((82, 238), "PTIT", fill=(255, 255, 255), font=font_big)
    draw.text((282, 238), "DCT GEO", fill=(20, 20, 20), font=font_small)
    draw.text((78, 420), "BLOCK 8x8 / MID-FREQUENCY", fill=(250, 250, 250), font=font_small)
    img.save(path)


def embed_array(gray: np.ndarray, bits: list[int], alpha: float = ALPHA, repeat_n: int = REPEAT_N) -> np.ndarray:
    out = gray.astype(np.float64).copy()
    order = block_order(len(bits), repeat_n=repeat_n)
    for idx, block_index in enumerate(order):
        bit = bits[idx // repeat_n]
        by = (block_index // (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE
        bx = (block_index % (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE
        block = out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
        coeff = dct2(block)
        a = coeff[COEFF_A]
        b = coeff[COEFF_B]
        diff = a - b
        target = alpha if bit else -alpha
        if bit and diff <= alpha:
            adjust = (alpha - diff) / 2.0 + 1.0
            coeff[COEFF_A] = a + adjust
            coeff[COEFF_B] = b - adjust
        elif not bit and diff >= -alpha:
            adjust = (diff + alpha) / 2.0 + 1.0
            coeff[COEFF_A] = a - adjust
            coeff[COEFF_B] = b + adjust
        else:
            coeff[COEFF_A] = a + (target * 0.02)
            coeff[COEFF_B] = b - (target * 0.02)
        out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] = idct2(coeff) + 128.0
    return np.clip(out, 0, 255)


def extract_bits(gray: np.ndarray, bit_count: int, repeat_n: int = REPEAT_N) -> tuple[list[int], list[list[int]]]:
    order = block_order(bit_count, repeat_n=repeat_n)
    recovered: list[int] = []
    votes: list[list[int]] = []
    for bit_index in range(bit_count):
        group: list[int] = []
        for rep in range(repeat_n):
            block_index = int(order[bit_index * repeat_n + rep])
            by = (block_index // (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE
            bx = (block_index % (IMAGE_SIZE // BLOCK_SIZE)) * BLOCK_SIZE
            block = gray[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
            coeff = dct2(block)
            group.append(1 if coeff[COEFF_A] > coeff[COEFF_B] else 0)
        votes.append(group)
        recovered.append(1 if sum(group) >= (repeat_n / 2.0) else 0)
    return recovered, votes


def embed_message(cover_path: str | Path, stego_path: str | Path, alpha: float = ALPHA, repeat_n: int = REPEAT_N) -> dict:
    bits = message_bits()
    cover = load_gray(cover_path)
    stego = embed_array(cover, bits, alpha=alpha, repeat_n=repeat_n)
    save_gray_as_rgb(stego, stego_path)
    metrics = {
        "message": MESSAGE,
        "alpha": alpha,
        "repeat_n": repeat_n,
        "psnr": psnr(cover, stego),
        "bit_count": len(bits),
    }
    write_json(work_path("embed_metrics.json"), metrics)
    return metrics


def extract_message(image_path: str | Path, repeat_n: int = REPEAT_N) -> dict:
    expected = message_bits()
    gray = load_gray(image_path)
    bits, votes = extract_bits(gray, len(expected), repeat_n=repeat_n)
    recovered = bits_to_message(bits)
    ber = bit_error_rate_from_bits(expected, bits)
    return {
        "message": recovered,
        "ber": ber,
        "votes": votes,
        "repeat_n": repeat_n,
    }


def psnr(original: np.ndarray, modified: np.ndarray) -> float:
    mse = np.mean((original.astype(np.float64) - modified.astype(np.float64)) ** 2)
    if mse == 0:
        return float("inf")
    return 20.0 * math.log10(255.0 / math.sqrt(mse))


def simple_ssim(a: np.ndarray, b: np.ndarray) -> float:
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    c1 = (0.01 * 255) ** 2
    c2 = (0.03 * 255) ** 2
    mu_a = a.mean()
    mu_b = b.mean()
    var_a = a.var()
    var_b = b.var()
    cov = ((a - mu_a) * (b - mu_b)).mean()
    return ((2 * mu_a * mu_b + c1) * (2 * cov + c2)) / ((mu_a**2 + mu_b**2 + c1) * (var_a + var_b + c2))


def write_report(path: str | Path, lines: list[str]) -> None:
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_json(path: str | Path, data: dict) -> None:
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def read_json(path: str | Path, default: dict | None = None) -> dict:
    p = Path(path)
    if not p.exists():
        return default or {}
    return json.loads(p.read_text(encoding="utf-8"))


def append_metric_row(path: str | Path, key_fields: tuple, row: dict) -> list[dict]:
    p = Path(path)
    rows = read_json(p, {"rows": []}).get("rows", [])
    rows = [item for item in rows if tuple(item.get(k) for k in key_fields) != tuple(row.get(k) for k in key_fields)]
    rows.append(row)
    rows.sort(key=lambda item: tuple(str(item.get(k, "")) for k in key_fields))
    write_json(p, {"rows": rows})
    return rows


def has_required_rows(rows: list[dict], keys: tuple, required: set[tuple]) -> bool:
    seen = {tuple(item.get(k) for k in keys) for item in rows}
    return required.issubset(seen)


def ensure_stego() -> Path:
    ensure_cover()
    stego = work_path("stego.png")
    if not stego.exists():
        embed_message(work_path("cover.png"), stego)
    return stego
