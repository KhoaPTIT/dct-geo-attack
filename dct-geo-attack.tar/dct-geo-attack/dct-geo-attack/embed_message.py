import argparse

from dct_helper import ALPHA, REPEAT_N, embed_message, ensure_cover, work_path, write_report


def main() -> None:
    parser = argparse.ArgumentParser(description="Embed the required message using 8x8 block DCT.")
    parser.add_argument("--alpha", type=float, default=ALPHA, help="Embedding strength. Try 25, 35, 50.")
    parser.add_argument("--repeat", type=int, default=REPEAT_N, help="Bit repetition count. Try 3 and 5.")
    args = parser.parse_args()
    cover = ensure_cover()
    metrics = embed_message(cover, work_path("stego.png"), alpha=args.alpha, repeat_n=args.repeat)
    write_report(
        work_path("embed_report.txt"),
        [
            "Baseline DCT embedding successful",
            f"Message: {metrics['message']}",
            f"ALPHA: {metrics['alpha']:.1f}",
            f"REPEAT_N: {metrics['repeat_n']}",
            f"PSNR: {metrics['psnr']:.2f} dB",
        ],
    )
    print(f"alpha={metrics['alpha']:.1f} repeat={metrics['repeat_n']} psnr={metrics['psnr']:.2f} dB")
    print("Output image: stego.png")


if __name__ == "__main__":
    main()
