from __future__ import annotations

from geo_attack import inverse_crop_approx, open_rgb, rotate_image, save_attack, translate_image
from dct_helper import (
    ALPHA,
    MESSAGE,
    REPEAT_N,
    embed_message,
    ensure_cover,
    extract_message,
    load_gray,
    psnr,
    work_path,
    write_json,
    write_report,
)


# TODO for students:
# Tune these parameters, rerun this script, and compare defense_report.txt.
# Larger search spaces can improve recovery but make the defense slower.
SEARCH_RADIUS = 8
ROTATION_CANDIDATES = [-5, -3, -1, 0, 1, 3, 5]
SCALE_CANDIDATES = [0.90, 0.95, 1.0, 1.05, 1.10]
REPEAT_N = 5
ALPHA = 35.0


def prepare_inputs() -> None:
    cover = ensure_cover()
    stego = work_path("stego.png")
    if not stego.exists():
        embed_message(cover, stego, alpha=ALPHA, repeat_n=REPEAT_N)
    composite = work_path("attacks/composite_attacked.png")
    if not composite.exists():
        import attack_composite

        attack_composite.main()


def try_candidate(source_img, scale: float, angle: int, dx: int, dy: int):
    candidate = inverse_crop_approx(source_img, scale)
    candidate = translate_image(candidate, -dx, -dy)
    candidate = rotate_image(candidate, -angle)
    tmp = work_path("_defense_candidate.png")
    save_attack(candidate, tmp)
    result = extract_message(tmp, repeat_n=REPEAT_N)
    return result, candidate


def main() -> None:
    prepare_inputs()
    cover_gray = load_gray(work_path("cover.png"))
    stego_gray = load_gray(work_path("stego.png"))
    stego_psnr = psnr(cover_gray, stego_gray)

    source = open_rgb(work_path("attacks/composite_attacked.png"))
    best = None
    best_img = None
    tested = 0

    def evaluate(scale: float, angle: int, dx: int, dy: int) -> None:
        nonlocal best, best_img, tested
        result, candidate = try_candidate(source, scale, angle, dx, dy)
        tested += 1
        if best is None or result["ber"] < best["ber"]:
            best = {
                "ber": result["ber"],
                "message": result["message"],
                "scale": scale,
                "angle": angle,
                "dx": dx,
                "dy": dy,
                "tested": tested,
            }
            best_img = candidate.copy()

    priority = [
        (0.90, 3, 5, 5),
        (0.95, 3, 5, 5),
        (1.00, 3, 5, 5),
        (0.90, 3, 4, 4),
        (0.90, 3, 6, 6),
        (0.90, 1, 5, 5),
        (0.90, 5, 5, 5),
    ]
    seen = set()
    for item in priority:
        seen.add(item)
        evaluate(*item)
        if best and best["ber"] <= 0.15:
            break

    if not best or best["ber"] > 0.15:
        for scale in SCALE_CANDIDATES:
            for angle in ROTATION_CANDIDATES:
                for dx in range(-SEARCH_RADIUS, SEARCH_RADIUS + 1):
                    for dy in range(-SEARCH_RADIUS, SEARCH_RADIUS + 1):
                        item = (scale, angle, dx, dy)
                        if item in seen:
                            continue
                        evaluate(*item)
                        if best and best["ber"] <= 0.15:
                            break
                    if best and best["ber"] <= 0.15:
                        break
                if best and best["ber"] <= 0.15:
                    break
            if best and best["ber"] <= 0.15:
                break

    if best_img is not None:
        save_attack(best_img, work_path("defended.png"))
    if work_path("_defense_candidate.png").exists():
        work_path("_defense_candidate.png").unlink()

    passed = (
        best is not None
        and stego_psnr >= 35.0
        and best["ber"] <= 0.15
        and REPEAT_N >= 5
        and 25.0 <= ALPHA <= 60.0
        and SEARCH_RADIUS >= 8
    )
    status = "Geometric resynchronization defense PASSED" if passed else "Geometric resynchronization defense FAILED"
    write_json(work_path("defense_metrics.json"), {"psnr": stego_psnr, **(best or {})})
    write_report(
        work_path("defense_report.txt"),
        [
            status,
            f"Expected message: {MESSAGE}",
            f"Recovered message: {(best or {}).get('message', '')}",
            f"PSNR: {stego_psnr:.2f} dB",
            f"Defense BER: {(best or {}).get('ber', 1.0) * 100.0:.2f}%",
            f"Best scale: {(best or {}).get('scale', 'n/a')}",
            f"Best rotation: {(best or {}).get('angle', 'n/a')}",
            f"Best translation dx,dy: {(best or {}).get('dx', 'n/a')},{(best or {}).get('dy', 'n/a')}",
            f"REPEAT_N: {REPEAT_N}",
            f"ALPHA: {ALPHA:.1f}",
            f"SEARCH_RADIUS: {SEARCH_RADIUS}",
        ],
    )
    print(f"status={status}")
    print(f"psnr={stego_psnr:.2f} dB defense_ber={(best or {}).get('ber', 1.0) * 100.0:.2f}%")
    print(f"best scale={(best or {}).get('scale', 'n/a')} rotation={(best or {}).get('angle', 'n/a')} dx={(best or {}).get('dx', 'n/a')} dy={(best or {}).get('dy', 'n/a')}")
    print("Edit SEARCH_RADIUS, ROTATION_CANDIDATES, SCALE_CANDIDATES, REPEAT_N, and ALPHA, then rerun if the defense fails.")


if __name__ == "__main__":
    main()
