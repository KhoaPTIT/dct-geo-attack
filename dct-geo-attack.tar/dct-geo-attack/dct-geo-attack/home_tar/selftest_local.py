from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
COMMANDS = [
    ["generate_cover.py"],
    ["embed_message.py", "--alpha", "35", "--repeat", "5"],
    ["extract_message.py", "--image", "stego.png", "--repeat", "5"],
    ["visualize_dct.py"],
    ["attack_translation.py", "--dx", "2", "--dy", "2"],
    ["attack_translation.py", "--dx", "5", "--dy", "5"],
    ["attack_translation.py", "--dx", "10", "--dy", "10"],
    ["attack_translation.py", "--dx", "20", "--dy", "20"],
    ["attack_crop.py", "--percent", "5"],
    ["attack_crop.py", "--percent", "10"],
    ["attack_crop.py", "--percent", "20"],
    ["attack_crop.py", "--percent", "30"],
    ["attack_rotation.py", "--angle", "1"],
    ["attack_rotation.py", "--angle", "3"],
    ["attack_rotation.py", "--angle", "5"],
    ["attack_rotation.py", "--angle", "10"],
    ["attack_scaling.py", "--scale", "90"],
    ["attack_scaling.py", "--scale", "75"],
    ["attack_scaling.py", "--scale", "50"],
    ["attack_composite.py", "--angle", "3", "--dx", "5", "--dy", "5", "--crop", "10"],
    ["registration_defense.py"],
    ["summary.py"],
]
CHECKS = {
    "embed_report.txt": "Baseline DCT embedding successful",
    "baseline_report.txt": "Clean extraction BER = 0.00%",
    "visual_report.txt": "DCT spectrum visualized",
    "translation_report.txt": "Translation Attack BER Analysis",
    "crop_report.txt": "Crop Attack BER Analysis",
    "rotation_report.txt": "Rotation Attack BER Analysis",
    "scaling_report.txt": "Scaling Attack BER Analysis",
    "composite_report.txt": "Composite Geometric Attack BER Analysis",
    "defense_report.txt": "Geometric resynchronization defense PASSED",
    "summary_report.txt": "Summary Completed",
}


def remove_outputs() -> None:
    patterns = [
        "*.png",
        "*.txt",
        "*.json",
        "_defense_candidate.png",
        "attacks/*.png",
    ]
    for pattern in patterns:
        for path in ROOT.glob(pattern):
            if path.name in {"STUDENT_GUIDE.md"}:
                continue
            if path.is_file():
                path.unlink()
    attacks = ROOT / "attacks"
    if attacks.exists() and not any(attacks.iterdir()):
        attacks.rmdir()


def run_command(command: list[str]) -> bool:
    proc = subprocess.run([sys.executable, *command], cwd=ROOT, text=True, capture_output=True)
    if proc.returncode != 0:
        print(f"FAIL {' '.join(command)}")
        print(proc.stdout)
        print(proc.stderr)
        return False
    print(f"PASS {' '.join(command)}")
    return True


def check_reports() -> bool:
    ok = True
    for name, needle in CHECKS.items():
        path = ROOT / name
        text = path.read_text(encoding="utf-8") if path.exists() else ""
        if needle in text:
            print(f"PASS check {name}")
        else:
            print(f"FAIL check {name}: missing {needle}")
            ok = False
    return ok


def main() -> int:
    remove_outputs()
    ok = True
    for command in COMMANDS:
        ok = run_command(command) and ok
    ok = check_reports() and ok
    print("PASS selftest_local.py" if ok else "FAIL selftest_local.py")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
