import argparse

from geo_attack import open_rgb, save_attack, scale_down_up_image
from dct_helper import REPEAT_N, append_metric_row, ensure_stego, extract_message, has_required_rows, terminal_text, work_path, write_report


REQUIRED = {90, 75, 50}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one scaling attack experiment.")
    parser.add_argument("--scale", type=int, required=True, choices=[90, 75, 50], help="Downscale percentage.")
    parser.add_argument("--repeat", type=int, default=REPEAT_N)
    args = parser.parse_args()
    stego = ensure_stego()
    img = open_rgb(stego)
    scale = args.scale / 100.0
    out = work_path(f"attacks/scaling_{args.scale}.png")
    save_attack(scale_down_up_image(img, scale), out)
    result = extract_message(out, repeat_n=args.repeat)
    rows = append_metric_row(
        work_path("scaling_metrics.json"),
        ("scale",),
        {"scale": args.scale, "ber": result["ber"], "message": result["message"]},
    )
    complete = has_required_rows(rows, ("scale",), {(x,) for x in REQUIRED})
    lines = ["Scaling Attack BER Analysis" if complete else "Scaling Attack Experiments In Progress"]
    lines.append("Required scale: 90, 75, 50")
    lines.append("scale_percent,BER_percent,recovered_message")
    for row in rows:
        lines.append(f"{row['scale']},{row['ber'] * 100.0:.2f},{row['message']}")
    write_report(work_path("scaling_report.txt"), lines)
    print(f"scale={args.scale}% image=attacks/scaling_{args.scale}.png")
    print(f"BER={result['ber'] * 100.0:.2f}% recovered={terminal_text(result['message'])}")
    print("Completed all required scaling levels." if complete else "Run the remaining required scaling levels.")


if __name__ == "__main__":
    main()
